#  Bootstrap carousel multiple items increment by 1 (jQuery)

A Pen created on CodePen.io. Original URL: [https://codepen.io/codingyaar/pen/xxjpqyB](https://codepen.io/codingyaar/pen/xxjpqyB).

How to create a responsive Bootstrap 5 carousel with multiple items and slide one card per click.